<?php

?>
<!DOCTYPE html>
<head>
</head>
<body>

	<table width="100%" bgcolor="white" cellpadding="4" cellspacing="4">
            <tr >
                <td width="25%">
                    <img src="s-logo.gif" alt="" height="20" width="20"> <a href="home.php"><span class="menu">Home</span>
                </td>
                <td width="25%">
                    <img src="s-logo.gif" alt="" height="20" width="20"><a href="contact.php"> <span class="menu">Contact</span>
                </td>
                <td width="25%">
                    <img src="s-logo.gif" alt="" height="20" width="20"> <a href="services.php"><span class="menu">Services</span>
                </td>
                <td width="25%">
                    <img src="s-logo.gif" alt="" height="20" width="20"><a href="sitemap.php"> <span class="menu">Site Map</span>
                </td>
            </tr>
        </table>
        
	</body>
</html>
	