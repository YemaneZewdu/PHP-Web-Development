<?php

?>
<!DOCTYPE html>
<head>
</head>
    <body>
        <!-- page header -->
        <table width="100%" cellpadding="12" cellspacing="0" border="0">
            <tr bgcolor="black">
                <td align="left"><img src="logo.gif" alt="TLA logo" height="70" width="70"></td>
                <td>
                    <h1>TLA Consulting</h1>
                </td>
                <td align="right"><img src="logo.gif" alt="TLA logo" height="70" width="70"></td>
            </tr>
        </table>
  </body>
</html>
