<?php
/*
Yemane Zewdu
Assignment 03 
*/

$carType=$_POST['carType']; 
$component=$_POST['Component'];
?>

<html>
	<title> checkup </title>
<body>
	<h1>price checkup ?</h1>

<?php 
 /*
	$categories = array( array ( array ( "car_tir", 'tire', 100) ,
								array ('car_oil','oil', 10),
								array ('car_spk', 'spark plugs',4) ) ,
					array ( array ('van_tir', 'Tire', 120) ,
							array ('van_oil', 'oil', 12) ,
							array ('van_spark', 'spark plug', 6) ),  
					array ( array ('truck_tir', 'Tire', 120) ,
							array ('truck_oil', 'oil', 12) ,
							array ('truck_spk', 'spark plug', 6) ));  

	for ($layer = 0 ; $layer < 3; $layer++) {
		echo 'layer'.$layer."<br />" ;
			for ($row = 0 ; $row < 3 ; $row++ ) {		
				for ($column = 0 ; $column < 3 ; $column++){
					echo '|' .$categories [$layer][$row][$column];
				}
				echo '|<br />' ;
			}
	}
	*/

	 echo "Car Type: " ;
		if ($carType=="d"){
			echo "Car <br>";
		}
		elseif ($carType=="e"){
			echo " Van <br>";
		}
		elseif ($carType=="f"){
			echo "Truck <br>";
		} 
		
	echo "component: ";
		if($component=="a" ){
			echo  "oil <br> " ; 
		}
		elseif ($component=="b"){
			echo " tire <br> " ; 
			}
		elseif ($component=="c"){
			echo " spark plug <br> " ; 
			} 


		if ($component=="a") { 
			if	($carType=="d") {
				echo " price: $10";
			}
		}
		elseif($component=="c") {
			if ($carType=="d"){
				echo " price : $4 ";
			}
		}
		elseif($component=="b") {
			if	($carType=="d") {
				echo " price: $100";
			}
		}
		if($component=="c") { 
			if ($carType=="e"){
				echo " price : $5 ";
			}
		}
		elseif ($component=="a") {
			if	($carType=="e") {
				echo " price: $12";
			} 
		}
		elseif($component=="b") {
			if ($carType=="e"){
				echo " price : $120 ";
			}
		}
		if($component=="c") {
			if ($carType=="f"){
				echo " price : $6 ";
			}
		}
		elseif ($component=="a") {
			if	($carType=="f") {
				echo " price: $15";
			}
		}
		elseif($component=="b") { 
			if ($carType=="f"){
				echo " price : $150 ";
			}
		}
		
?>

</body>
</html>